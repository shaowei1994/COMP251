
public class mancala{

    public static void main(String[] args){

    }
}
